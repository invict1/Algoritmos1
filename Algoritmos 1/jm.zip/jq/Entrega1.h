#ifndef ENTREGA1_H
#define ENTREGA1_H

#include "Definiciones.h"

#include "ListaOrd.h"
#include "ListaPos.h"
#include "Pila.h"
#include "Cola.h"

#include "ListaOrdImp.h"
#include "ListaPosImp.h"
#include "PilaImp.h"
#include "ColaImp.h"

// Ver Entrega1.txt para la documentaci�n de estas funciones

template <class T>
ListaOrd<T> *UnionListaOrd(const ListaOrd<T> &l1, const ListaOrd<T> &l2)	//es igual que el intercalar. compara y te moves sobre el iterador que tiene y avanzas 
{
	ListaOrd<T> * lret = new ListaOrdImp<T>();	//siempre del lado del new va la imp
	Iterador<T> it = l1.GetIterador();
	Iterador<T> it2 = l2.GetIterador();
	while (!it.EsFin() && !it2.EsFin()) {
		T elemento1 = it.Elemento();
		T elemento2 = it2.Elemento();
		if (elemento1 <= elemento2){
			lret->AgregarOrd(elemento1);
			it++;
		} 
		else {
			lret->AgregarOrd(elemento2);
			it2++;
		}
	}
	while (!it.EsFin()) {
		T elemento = it.Elemento();
		lret->AgregarOrd(elemento);
		it++;
	}
	while (!it2.EsFin()) {
		T elemento = it2.Elemento();
		lret->AgregarOrd(elemento);
		it2++;
	}
	return lret;	
}

ListaOrd<int>* Enlistar(NodoAB* a);

template <class T>
bool EstaContenida(const Pila<T> &p1, const Pila<T> &p2)
{
	bool retorno = false;
	if (p2.CantidadElementos() >= p1.CantidadElementos()) {
		Pila<T>* clonP1 = p1.Clon();
		Pila<T>* clonP2 = p2.Clon();
		ListaOrd<T>* p1EnLista = new ListaOrdImp<T>();
		ListaOrd<T>* p2EnLista = new ListaOrdImp<T>();
		while (!clonP1->EsVacia()) {
			p1EnLista->AgregarOrd(clonP1->Pop());
		}
		while (!clonP2->EsVacia()) {
			p2EnLista->AgregarOrd(clonP2->Pop());
		}
		while (!p2EnLista->EsVacia() && !p1EnLista->EsVacia()) {
			if (p2EnLista->Existe(p1EnLista->Minimo())) {
				p2EnLista->Borrar(p1EnLista->Minimo());
				p1EnLista->BorrarMinimo();
			}
			else p2EnLista->BorrarMinimo();
		}
		retorno = p1EnLista->EsVacia();
		delete clonP1;
		delete clonP2;
		delete p1EnLista;
		delete p2EnLista;
		clonP1 = clonP2 = NULL;
		p1EnLista = p2EnLista = NULL;
	}
	return retorno;
}

int CantidadDeHojas(NodoAB* a);

void ImprimirPorNiveles(NodoAB *a);

#endif