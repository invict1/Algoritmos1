#include "PilaImp.h"			// PRONTO

#ifndef PILAIMP_CPP
#define PILAIMP_CPP

template <class T> //CLASE
inline ostream &operator<<(ostream& out, const PilaImp<T> &c) {
	c.Imprimir(out);
	return out;
}

template <class T> //CLASE
PilaImp<T>::PilaImp() {
	this->ppio = NULL;
	this->cantidadElementos = 0;
}

template<class T> //CLASE
PilaImp<T>::PilaImp(const Pila<T>& p) {
	this->ppio = NULL;
	this->cantidadElementos = 0;
	*this = p;	//paso todos lo elementos de p a this
}

template<class T> //CLASE
PilaImp<T>::PilaImp(const PilaImp<T>& p) {
	this->ppio = NULL;
	this->cantidadElementos = 0;
	*this = p;
}

template<class T> //CLASE
Pila<T>& PilaImp<T>::operator=(const Pila<T>& p) { //hacer operaciones del tad sobre t en mi estructura. hacer pushs de uno al otro
	if (this != &p) {	//pregunto si no son el mismo. Ahora necesito ver como recorrer el TAD
		this->Vaciar();	//lo vac�o por si tiene alg�n elemento
		Pila<T>* clon = p.Clon();
		Pila<T>* intermedio = new PilaImp<T>();
		while (!clon->EsVacia()) {
			intermedio->Push(clon->Pop());
		}
		while (!intermedio->EsVacia()) {
			this->Push(intermedio->Pop());
		}
		delete intermedio;
		delete clon;
	}
	return *this;
}

template<class T> //CLASE
Pila<T>& PilaImp<T>::operator=(const PilaImp<T>& p) {	//si funciona el gen�rico, el implementaci�n va a funcionar tambi�n
	if (this != &p) {	//pregunto si no son el mismo. Ahora necesito ver como recorrer el TAD
		this->Vaciar();	//lo vac�o por si tiene alg�n elemento
		Pila<T>* clon = p.Clon();
		Pila<T>* intermedio = new PilaImp<T>();
		while (!clon->EsVacia()) {
			intermedio->Push(clon->Pop());
		}
		while (!intermedio->EsVacia()) {
			this->Push(intermedio->Pop());
		}
		delete intermedio;
		delete clon;
	}
	return *this;
}

template<class T> //CLASE
bool PilaImp<T>::operator==(const Pila<T> &p) const{	//hay que fijarse si la cantidad es igual o no
	if (this->CantidadElementos()!=p.CantidadElementos())
		return false;
	Pila<T>* yo = this->Clon();
	Pila<T>* otro = p.Clon();
	bool iguales = true;
	while (!yo->EsVacia() && iguales) {
		iguales = yo->Top() == otro->Top();	// comparo sin sacarlo. ac� estoy igualando objetos
		yo->Pop();	//los saco para que no sea loop infinito. Se podr�a hacer en una l�nea con pop
		otro->Pop();
	}
	delete yo;
	delete otro;
	yo = otro = NULL;
	return iguales;
}

template<class T> //VIEJO
PilaImp<T>::~PilaImp() {
	this->Vaciar();
}

template<class T> //CLASE
Pila<T>* PilaImp<T>::CrearVacia() const {
	return new PilaImp<T>();
}

template<class T> //VIEJO
void PilaImp<T>::Push(const T& e) {
	NodoLista<T>* nuevo = new NodoLista<T>(e, NULL, this->ppio);
	this->ppio = nuevo;
	this->cantidadElementos++;
}

template<class T> //VIEJO
T& PilaImp<T>::Top() const {
	assert(!this->EsVacia());
	return this->ppio->dato;
}

template<class T> //VIEJO
T PilaImp<T>::Pop() {
	assert(!this->EsVacia());
	T copia = *new T(this->ppio->dato);
	NodoLista<T>* aBorrar = this->ppio;
	this->ppio = this->ppio->sig;
	delete aBorrar;
	this->cantidadElementos--;
	return copia;
}

template<class T>  //VIEJO
void PilaImp<T>::Vaciar() {
	while (!this->EsVacia()) {
		this->Pop();
	}	
}

template<class T> //VIEJO
unsigned int PilaImp<T>::CantidadElementos() const {
	return this->cantidadElementos;
}

template<class T> //VIEJO
bool PilaImp<T>::EsVacia() const {
	return this->cantidadElementos == 0;
}

template <class T> //CLASE
bool PilaImp<T>::EsLlena() const {
	return false;					// NO es un TAD acotado
}

template<class T> //VIEJO
Pila<T>* PilaImp<T>::Clon() const {	// es similar al == pero no puedo llamar al clon, entonces aca si vamos a tener que recorrer los nodos. para acceder a los atributos le pongo PilaImp en la primera parte
	Pila<T>* retorno = new PilaImp();
	Pila<T>* alReves = new PilaImp();
	NodoLista<T>* temp = this->ppio;
	while (temp != NULL) {
		alReves->Push(temp->dato);
		temp = temp->sig;
	}
	while (!alReves->EsVacia()) {
		retorno->Push(alReves->Pop());
	}
	delete alReves;
	return retorno;
}

template<class T> //VIEJO
void PilaImp<T>::Imprimir(ostream & o) const {
	Pila<T> *clon = this->Clon();
	while (!clon->EsVacia()) {
		T e = clon->Top();
		clon->Pop();
		if (clon->EsVacia())
			o << e;
		else
			o << e << " ";
	}
	delete clon;
	clon = NULL;	//preguntar si es necesario
}

#endif