#ifndef TIPO_RETORNO_H
#define TIPO_RETORNO_H

enum _retorno
{
	OK, ERROR, NO_IMPLEMENTADA, COMENTADA
};
typedef enum _retorno TipoRetorno;

#endif