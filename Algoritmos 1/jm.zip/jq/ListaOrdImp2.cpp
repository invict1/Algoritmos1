#include "ListaOrdImp2.h"

#ifndef LISTAORDIMP2_CPP
#define LISTAORDIMP2_CPP

template <class T> //VIEJO
inline ostream &operator<<(ostream& out, const ListaOrdImp2<T> &l) {
	l.Imprimir(out);
	return out;
}

template <class T> //VIEJO
ListaOrd<T>* ListaOrdImp2<T>::CrearVacia() const {
	return new ListaOrdImp2<T>();
}

template <class T> //VIEJO
ListaOrdImp2<T>::ListaOrdImp2() {
	this->arbol = NULL;
	this->cantElementos = 0;
}

template <class T> //VIEJO
ListaOrdImp2<T>::ListaOrdImp2(const ListaOrd<T> &l) {
	this->arbol = NULL;
	this->cantElementos = 0;
	*this = l;
}

template <class T> //VIEJO
ListaOrdImp2<T>::ListaOrdImp2(const ListaOrdImp2<T> &l) {
	this->arbol = NULL;
	this->cantElementos = 0;
	*this = l;
}

template <class T> //VIEJO
ListaOrd<T> &ListaOrdImp2<T>::operator=(const ListaOrd<T> &l) {
	if (this != &l) {
		this->Vaciar();
		for (Iterador<T> &i = l.GetIterador(); !i.EsFin();) {
			AgregarOrd(i++);
		}
	}
	return *this;
}

template <class T> //VIEJO
ListaOrd<T> &ListaOrdImp2<T>::operator=(const ListaOrdImp2<T> &l) {
	if (this != &l) {
		this->Vaciar();
		for (Iterador<T> &i = l.GetIterador(); !i.EsFin();) {
			AgregarOrd(i++);
		}
	}
	return *this;
}

template <class T> //VIEJO
ListaOrdImp2<T>::~ListaOrdImp2() {
	this->Vaciar();
}

template <class T>	//VIEJO AUXILIAR
void ListaOrdImp2<T>::insertar(T dato, NodoABB<T>* & abb) {
	if (abb == NULL) {
		abb = new NodoABB<T>(dato);
	}
	else if (dato < abb->dato) insertar(dato, abb->izq);
	else if (dato > abb->dato) insertar(dato, abb->der);
	else abb->auxiliar++;
}

template <class T> //VIEJO
void ListaOrdImp2<T>::AgregarOrd(const T &e) {
	insertar(e, this->arbol);
	this->cantElementos++;
}

template <class T>	//VIEJO AUXILIAR
void ListaOrdImp2<T>::elimMin(NodoABB<T>* & abb) {
	if (abb != NULL) {
		if (abb->izq != NULL) elimMin(abb->izq);
		else {
			if (abb->auxiliar > 0) abb->auxiliar--;
			else {
				NodoABB<T>* aBorrar = abb;
				abb = abb->der;
				delete aBorrar;
			}
		}
	}
}

template <class T> //VIEJO
void ListaOrdImp2<T>::BorrarMinimo() {
	elimMin(this->arbol);
	this->cantElementos--;
}

template <class T>	//VIEJO AUXILIAR
void ListaOrdImp2<T>::elimMax(NodoABB<T>* & abb) {
	if (abb != NULL) {
		if (abb->der != NULL) elimMin(abb->der);
		else {
			if (abb->auxiliar > 0) abb->auxiliar--;
			else {
				NodoABB<T>* aBorrar = abb;
				abb = abb->izq;
				delete aBorrar;
			}
		}
	}
}

template <class T>	//VIEJO
void ListaOrdImp2<T>::BorrarMaximo() {
	elimMax(this->arbol);
	this->cantElementos--;
}

template <class T>	//VIEJO AUXILIAR
void ListaOrdImp2<T>::elim(NodoABB<T>* & abb, T dato) {
	if (abb != NULL) {
		if (dato < abb->dato) elim(abb->izq, dato);
		else if (dato > abb->dato) elim(abb->der, dato);
		else { //dato == abb->dato
			if (abb->auxiliar > 0) abb->auxiliar--;
			else if (abb->izq == NULL) {
				NodoABB<T>* aBorrar = abb;
				abb = abb->der;
				delete aBorrar;
			}
			else if (abb->der == NULL) {
				NodoABB<T>* aBorrar = abb;
				abb = abb->izq;
				delete aBorrar;
			}
			else {
				NodoABB<T>* minimo = min(abb->der);
				abb->dato = minimo->dato;
				abb->auxiliar = minimo->auxiliar;
				minimo->auxiliar = 0;
				elim(abb->der, abb->dato);
			}
		}
	}
}

template <class T>	//VIEJO
void ListaOrdImp2<T>::Borrar(const T &e) {
	elim(this->arbol, e);
	this->cantElementos--;
}

template <class T>	//VIEJO AUXILIAR
NodoABB<T>* ListaOrdImp2<T>::min(NodoABB<T>* abb) const {
	if (abb == NULL) return NULL;
	else if (abb->izq != NULL) return min(abb->izq);
	else return abb;
}

template <class T>	//VIEJO
const T& ListaOrdImp2<T>::Minimo() const {
	return min(this->arbol)->dato;
}

template <class T>	//VIEJO AUXILIAR
NodoABB<T>* ListaOrdImp2<T>::max(NodoABB<T>* abb) const {
	if (abb == NULL) return NULL;
	else if (abb->der != NULL) return min(abb->der);
	else return abb;
}

template <class T>	//VIEJO
const T& ListaOrdImp2<T>::Maximo() const {
	return max(this->arbol)->dato;
}

template <class T>	//VIEJO AUXILIAR
NodoABB<T>* ListaOrdImp2<T>::buscar(NodoABB<T>* abb, T x) const {
	bool esta;
	esta = false;
	while (abb != NULL && !esta) {
		if (abb->dato == x) esta = true;
		else if (abb->dato > x) abb = abb->izq;
		else abb = abb->der;
	}
	return abb;
}

template <class T>	//VIEJO
const T& ListaOrdImp2<T>::Recuperar(const T &e) const {
	NodoABB<T>* buscado = buscar(this->arbol, e);
	return buscado->dato;
}

template <class T> //VIEJO
bool ListaOrdImp2<T>::Existe(const T &e) const {
	return buscar(this->arbol, e) != NULL;
}

template <class T> //VIEJO
void ListaOrdImp2<T>::Vaciar() {
	while (!this->EsVacia()) {
		this->Borrar(this->arbol->dato);
	}
}

template <class T> //VIEJO
unsigned int ListaOrdImp2<T>::CantidadElementos()const {
	return this->cantElementos;
}

template <class T> //VIEJO
bool ListaOrdImp2<T>::EsVacia()const {
	return this->cantElementos == 0;
}

template <class T>	//VIEJO AUXILIAR
bool ListaOrdImp2<T>::EsLlena()const {	//porque el TAD no es acotado
	return false;
}

template<class T> //VIEJO
ListaOrd<T>* ListaOrdImp2<T>::Clon() const {
	ListaOrd<T>* clon = new ListaOrdImp2<T>();
	Iterador<T> it = this->GetIterador();
	for (Iterador<T>& i = this->GetIterador(); !i.EsFin();) {
		clon->AgregarOrd(i++);
	}
	return clon;
}

template <class T>	//VIEJO AUXILIAR
void ListaOrdImp2<T>::deArbolALista(NodoABB<T>* abb, ListaPosImp<T>* l) const {
	if (abb != NULL) {
		deArbolALista(abb->der, l);
		for (int i = abb->auxiliar; i >= 0; i--) {
			l->AgregarPpio(abb->dato);
		}
		deArbolALista(abb->izq, l);
	}
}

template <class T> //VIEJO
Iterador<T> ListaOrdImp2<T>::GetIterador() const {
	ListaPosImp<T> l;
	deArbolALista(this->arbol, &l); // SUGERENCIA: aqui cargar en l con los elementos de this ordenados de menor a mayor (con funcion auxiliar)
	return IteradorListaOrdImp2<T>(l);
}

template <class T> //VIEJO
void ListaOrdImp2<T>::Imprimir(ostream& o) const {
	for (Iterador<T> &i = GetIterador(); !i.EsFin();) {
		o << i++ << " ";
	}
}


#endif