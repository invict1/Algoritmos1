#include "ColaImp.h"		// PRONTO

#ifndef COLAIMP_CPP
#define COLAIMP_CPP

template <class T>
ostream &operator<<(ostream& out, const ColaImp<T> &c) {
	c.Imprimir(out);
	return out;
}

template <class T> //VIEJO
ColaImp<T>::ColaImp(){
	T* basura = new T();
	this->ppio = new NodoLista<T>(*basura, NULL, NULL);
	this->fin = this->ppio;
	this->cantElementos = 0;
}

template <class T> //VIEJO
ColaImp<T>::ColaImp(const Cola<T> &c){
	this->ppio = NULL;
	this->fin = NULL;
	this->cantElementos = 0;
	*this = c;
}

template <class T> //VIEJO
ColaImp<T>::ColaImp(const ColaImp<T> &c){
	this->ppio = NULL;
	this->fin = NULL;
	this->cantElementos = 0;
	*this = c;
}

template <class T> //VIEJO
Cola<T> & ColaImp<T>::operator=(const Cola<T> &c){
	if (this != &c) {
		this->Vaciar();
		Cola<T>* clonC = c.Clon();
		while (!clonC->EsVacia()) {
			this->Encolar(clonC->Desencolar());
		}
		delete clonC;
	}
	return *this;
}

template <class T> //VIEJO
Cola<T> & ColaImp<T>::operator=(const ColaImp<T> &c){
	if (this != &c) {
		this->Vaciar();
		Cola<T>* clonC = c.Clon();
		while (!clonC->EsVacia()) {
			this->Encolar(clonC->Desencolar());
		}
		delete clonC;
	}
	return *this;
}

template <class T> //VIEJO
bool ColaImp<T>::operator==(const Cola<T>& c) const{
	Cola<T>* clonC = c.Clon();
	Cola<T>* clonThis = this->Clon();
	bool retorno = !clonC->EsVacia() && !clonThis->EsVacia();
	while (!clonC->EsVacia() && !clonThis->EsVacia()) {
		if (clonC->Desencolar() != clonThis->Desencolar()) retorno = false;
	}
	delete clonC;
	delete clonThis;
	return retorno;
}

template <class T> //VIEJO
ColaImp<T>::~ColaImp(){
	this->Vaciar();
}

template<class T> //VIEJO
Cola<T>* ColaImp<T>::CrearVacia() const {
	return new ColaImp<T>();
}

template <class T> //VIEJO
void ColaImp<T>::Encolar(const T &e){
	NodoLista<T>* nuevo = new NodoLista<T>(e, NULL, NULL);
	this->fin->sig = nuevo;
	this->fin = nuevo;
	this->cantElementos++;
}

template <class T> //VIEJO
T& ColaImp<T>::Principio()const{
	assert(!this->EsVacia());
	return this->ppio->sig->dato;
}

template <class T> //VIEJO
T ColaImp<T>::Desencolar(){
	assert(!this->EsVacia());
	T copia = *new T(this->ppio->sig->dato);
	NodoLista<T>* aBorrar = this->ppio;
	this->ppio = this->ppio->sig;
	delete aBorrar;
	this->cantElementos--;
	return copia;
}

template <class T> //VIEJO
void ColaImp<T>::Vaciar(){
	while (!this->EsVacia()) {
		this->Desencolar();
	}
}

template <class T> //VIEJO
unsigned int ColaImp<T>::CantidadElementos()const{
	return this->cantElementos;
}

template <class T> //VIEJO
bool ColaImp<T>::EsVacia() const{
	return this->cantElementos == 0;
}

template <class T> //VIEJO
bool ColaImp<T>::EsLlena() const{
	return false;					//NO es un TAD acotado
}

template <class T> //VIEJO
Cola<T>* ColaImp<T>::Clon()const{
	Cola<T>* retorno = new ColaImp();
	NodoLista<T>* temp = this->ppio->sig;
	while (temp != NULL) {
		retorno->Encolar(temp->dato);
		temp = temp->sig;
	}
	return retorno;
}

template <class T> //VIEJO
void ColaImp<T>::Imprimir(ostream& o)const{ 
	Cola<T> *clon = this->Clon();
	T elemento;
	while (!clon->EsVacia()) {
		elemento = clon->Desencolar();
		if (clon->EsVacia())
			o << elemento;
		else
			o << elemento << " ";
	}
	delete clon;
}

#endif