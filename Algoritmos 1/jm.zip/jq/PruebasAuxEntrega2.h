#ifndef PRUEBAS_AUX_ENTREGA2_H
#define PRUEBAS_AUX_ENTREGA2_H


#include "FuncAux.h"
#include "Entrega2.h"
#include "FuncAuxTAD.h"


void pruebaObtenerRepetidos(char *lista);
void pruebaContarOcurrencias(char *lista);
void pruebaXor(char* inputMultiSet1, char* inputMultiSet2);
void pruebaParentesisBalanceados(char *formula);
void pruebaImprimirPorNivelesAG(char* inputTree);

#endif