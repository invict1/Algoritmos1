#ifndef PRUEBAS_AUX_ENTREGA1_H
#define PRUEBAS_AUX_ENTREGA1_H


#include "FuncAux.h"
#include "FuncAuxTAD.h"
#include "Entrega1.h"

void pruebaEstaContenida(char* inputList1, char* inputList2);

void pruebaUnionListaOrd(char* inputList1, char* inputList2);

void pruebaEnlistar(char* inputTree);

void pruebaCantidadDeHojas(char* inputTree);

void pruebaImprimirPorNiveles(char* inputTree);

#endif