#pragma once				// HECHO

#ifndef LISTAPOS_H
#define LISTAPOS_H

#include <iostream>
using namespace std;
#include "Iterador.h"
#include "Iterable.h"

template <class T>
class ListaPos;	//esta es la especificacion, la de m�s arriba

// Escribe los elementos de la lista en el flujo out
template <class T>
inline ostream &operator<<(ostream& out, const ListaPos<T> &l) {
	l.Imprimir(out);
	return out;
}

template <class T>
class ListaPos abstract : public Iterable<T> {	//este abstract es para que no se puedan crear elementos de este tipo

public:

	// PRE: -
	// POS: Destructor
	virtual ~ListaPos() { } //se llama al hacer el delete o al final de un metodo si se tienen que borrar las variables locales. no se puede hacer new pero esta para poder borrar los atributos

	// PRE: -
	// POS: Retorna una nueva coleccion vacia
	virtual ListaPos<T> *CrearVacia() const abstract;

	//PRE:-
	//POS: Retorna una nueva lista id�ntica a this y sin compartir memoria            -- es util cuando recibimos algo y no lo podemos modificar
	virtual ListaPos<T> *Clon() const abstract; //segundo const: podes trabajar con los atributos de la clase pero no los podes modificar. virtual va siempre.

	// PRE: !EsLlena()			-- por si es acotada. como no es acotada, el es llena siempre devuelve false
	// POS: Agrega el elemento e al principio de la lista
	virtual void AgregarPpio(const T &e) abstract; //const porque es constante y el & porque le paso el original y no una copia por un tema de eficiencia

	// PRE: -
	// POS: Agrega el elemento e en la posicion pos de la lista
	//		El primer elemento se encuentra en la posicion 0.
	//		Si pos es mayor o igual al largo de la lista insertal al final
	virtual void AgregarPos(const T &e, unsigned int pos) abstract;

	// PRE: !EsLlena()
	// POS: Agrega el elemento e al final de la lista
	virtual void AgregarFin(const T &e) abstract;

	// PRE: -
	// POS: Borra el primer elemento de la lista. Si no hay elementos no tiene efecto
	virtual void BorrarPpio() abstract;

	// PRE: -
	// POS: Borra el ultimo elemento de la lista. Si no hay elementos no tiene efecto
	virtual void BorrarFin() abstract;

	// PRE: -
	// POS: Borra el elemento en la posicion pos de la lista
	//		El primer elemento se encuentra en la posicion 0.
	//		Si pos es mayor o igual al largo de la lista la operacion no tiene efecto
	virtual void BorrarPos(unsigned int pos) abstract;

	// PRE: -
	// POS: Borra el primer elemento que sea igual a e
	//		Usa el operador == del elemento e para encontrar uno igual.
	//		Si no encuentra no tiene efecto
	virtual void Borrar(const T &e) abstract;

	// PRE: !EsVacia()
	// POS: Retorna el primer elemento 
	virtual T& ElementoPpio() const abstract; //se podria devolver con el const despues del virtual para que no se pueda editar lo que devuelve. el segundo const: no puedo modificar los atributos de la clase

	// PRE: !EsVacia()
	// POS: Retorna el ultimo elemento 	
	virtual T& ElementoFin() const abstract;

	// PRE: 0 <= pos < CantidadElementos()
	// POS: Retorna el elemento en la posicion pos
	//		El primer elemento se encuentra en la posicion 0.
	virtual T& ElementoPos(unsigned int pos) const abstract;

	// PRE: Existe(e) 
	// POS: Retorna la posicion del primer elemento que sea igual a e
	//		Usa el operador == del elemento e para encontrar uno igual
	//		El primer elemento se encuentra en la posicion 0.
	virtual unsigned int Posicion(const T &e) const abstract;

	// PRE: -
	// POS: Busca si existe un elemento que sea igual a e
	//		Usa el operador == del elemento e para encontrar uno igual
	virtual bool Existe(const T &e) const abstract;

	// PRE: -
	// POS: Vacia la lista
	virtual void Vaciar() abstract;	//mientras no sea vacia, borra al borra al principio

	// PRE: -
	// POS: Retorna true si la lista esta vacia
	virtual bool EsVacia() const abstract;

	// PRE: -
	// POS: Retorna true si la lista esta llena
	virtual bool EsLlena() const abstract;

	// PRE: -
	// POS: Retorna la cantidad de elementos presentes en la lista
	virtual unsigned int CantidadElementos() const abstract;

	//PRE:-
	//POS: Se llama desde el operator<<. Imprime los elementos de la Lista separados por un espacio en blanco
	//	   El listado debe aparecer ordenado de la primera a la ultima posicion.
	virtual void Imprimir(ostream& o) const abstract;

	// PRE: -
	// POS: Retorna si las 2 listas tienen los mismos elementos (comparados con el operador ==) 
	//      y en el mismo orden
	virtual bool operator==(const ListaPos<T> &l) const {
		Iterador<T> &i = l.GetIterador();
		Iterador<T> &i2 = this->GetIterador();
		while (!i.EsFin() && !i2.EsFin()) {
			if (!(i++ == i2++))
				return false;
		}
		if (i.EsFin() != i2.EsFin())
			return false;

		return true;
	}

	// PRE: -
	// POS: *this == l y no comparten memoria
	virtual ListaPos<T> &operator=(const ListaPos<T> &l) {
		if (this != &l) {
			this->Vaciar();

			for (Iterador<T> &i = l.GetIterador(); !i.EsFin();) {
				AgregarFin(i++);
			}
		}
		return *this;
	}

protected:

	ListaPos() { }
	ListaPos(const ListaPos &l) { assert(false); }

};


#endif