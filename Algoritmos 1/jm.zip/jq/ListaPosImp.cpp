#include "ListaPosImp.h"			// PRONTO

#ifndef LISTAPOSIMP_CPP
#define LISTAPOSIMP_CPP

template <class T> //CLASE
inline ostream & operator<<(ostream &out, const ListaPosImp<T> &l) {
	l.Imprimir(out);
	return out;
}

template <class T> //CLASE
ListaPos<T>* ListaPosImp<T>::CrearVacia() const {
	return new ListaPosImp<T>();
}

template <class T> //CLASE
ListaPosImp<T>::ListaPosImp() {
	this->vector = new T[2];	//this es porque es un puntero al objeto. lo inicializamos en 2 para que sea chico y se pueda ir agrandando
	this->largoVector = 2;
	this->cantidadElementos = 0;	//siempre hay que inicializar todos los atributos porque sino tienen basura
}

template <class T> //CLASE
ListaPosImp<T>::ListaPosImp(const ListaPos<T> &l) {
	this->vector = new T[2];
	this->largoVector = 2;
	this->cantidadElementos = 0;				
	*this = l;
}

template <class T> //CLASE 																										//	void main(){		
ListaPosImp<T>::ListaPosImp(const ListaPosImp<T> &l) { //inicializamos de la misma forma que el constructor por defecto			//		ListaPosImp<int> lista;														
	this->vector = new T[2];																									//		otro(lista);
	this->largoVector = 2;																										//	}
	this->cantidadElementos = 0;																								//	void otro(ListaPosImp<int> l){					
	*this = l;																													//		ListaPosImp<int> x;
}																																//	x = l; }																						

template <class T> //CLASE
ListaPos<T>& ListaPosImp<T>::operator=(const ListaPos<T> &l) { //me tengo que ir a fijar que tengo en ListaPos porque no puedo usar cantidadElementos
	if (this != &l) {
		this->Vaciar(); 
		for (Iterador<T> it = l.GetIterador(); !it.EsFin();) {		//	for (int i = 0; i < l.CantidadElementos(); i++) {
			T elemento = it.Elemento();								//		this->AgregarFin(l.ElementoPos(i));	
			this->AgregarFin(elemento);								//	} esto es orden n cuadrado
			it++; 
		}	//esto es para que sea en orden n						
	}
	return *this;
}

template <class T> //CLASE
ListaPos<T>& ListaPosImp<T>::operator=(const ListaPosImp<T> &l) { //si hay * antes de l, es un puntero y tengo que usar la flecha, si no, es un objeto y hay que usar el .
	if (this != &l) {// este if chequea de que no sean el mismo
		//delete[] this->vector;	//borro el vector 
		//this->vector = new T[this->largoVector];	// y lo creo de nuevo para emepezar a pasar los elementos
		//this->cantidadElementos = 0;	// el largo no lo seteo porque es el mismo que era antes
		this->Vaciar(); //vacio el vector y lo cargo de nuevo
		for (int i = 0; i < l.cantidadElementos; i++) {
			this->AgregarFin(l.vector[i]);	//� l.ElementoPos(i)
		}
	}
	return *this;
}

template <class T> //VIEJO
ListaPosImp<T>::~ListaPosImp() {
	delete[]this->vector;
}

template <class T> //CLASE
void ListaPosImp<T>::AgregarPpio(const T &e) {
	this->expandir();
	this->correrHaciaAdelante(0);
	this->vector[0] = e;
	this->cantidadElementos++;
}

template <class T> //VIEJO
void ListaPosImp<T>::AgregarFin(const T &e) {
	if (this->largoVector == this->cantidadElementos) {
		expandir();
	}
	this->vector[this->cantidadElementos] = e;
	this->cantidadElementos++;
}

template <class T> //CLASE
void ListaPosImp<T>::AgregarPos(const T &e, unsigned int pos) {
	this->expandir();
	this->correrHaciaAdelante(pos);
	this->vector[pos] = e;
	this->cantidadElementos++;
}

template <class T> //CLASE
void ListaPosImp<T>::BorrarPpio() {
	this->correrHaciaAtras(0);
	this->cantidadElementos--;
}

template <class T> //CLASE
void ListaPosImp<T>::BorrarFin() {
	this->cantidadElementos--;
}

template <class T> //CLASE
void ListaPosImp<T>::BorrarPos(unsigned int pos) {
	this->correrHaciaAtras(pos);
	this->cantidadElementos--;
}

template <class T> //VIEJO
void ListaPosImp<T>::Borrar(const T &e) {
	bool encontro = false;
	int i = 0;
	for (i; i < this->cantidadElementos - 1; i++)
	{
		if (!encontro && this->vector[i] == e) encontro = true;
		if (encontro) this->vector[i] = this->vector[i + 1];
	}
	if (!encontro && this->vector[i] == e) encontro = true;
	if (encontro) this->cantidadElementos--;
}

template <class T> //VIEJO
T& ListaPosImp<T>::ElementoPpio() const {
	assert(!this->EsVacia());
	return this->vector[0];
}

template <class T> //VIEJO	
T& ListaPosImp<T>::ElementoFin() const {
	assert(!this->EsVacia());
	return this->vector[this->cantidadElementos - 1];
}

template <class T> //VIEJO
T& ListaPosImp<T>::ElementoPos(unsigned int pos) const {
	assert(pos < this->CantidadElementos());
	return this->vector[pos];
}

template <class T> //VIEJO
unsigned int ListaPosImp<T>::Posicion(const T &e) const {
	int pos = 0;
	for (pos; pos < this->cantidadElementos && this->vector[pos] != e; pos++);
	return pos;
}

template <class T> //VIEJO
bool ListaPosImp<T>::Existe(const T &e) const {
	int pos = 0;
	for (pos; pos < this->cantidadElementos && this->vector[pos] != e; pos++);
	return (pos != this->cantidadElementos);
}

template <class T> //VIEJO
void ListaPosImp<T>::Vaciar() {
	this->cantidadElementos = 0;
}

template <class T> //VIEJO
unsigned int ListaPosImp<T>::CantidadElementos() const { 
	return this->cantidadElementos; 
}

template <class T> //VIEJO
bool ListaPosImp<T>::EsVacia() const {
	return this->cantidadElementos == 0;
}

template <class T> //CLASE
bool ListaPosImp<T>::EsLlena() const {
	return false;	// porque la lista no es acotada
}

template <class T> //VIEJO
ListaPos<T>* ListaPosImp<T>::Clon() const {
	ListaPos<T>* clon = new ListaPosImp<T>();
	for (Iterador<T>& i = this->GetIterador(); !i.EsFin();) {
		clon->AgregarFin(i++);
	}
	return clon;
}

template <class T> //CLASE
Iterador<T> ListaPosImp<T>::GetIterador() const {
	return IteradorListaPosImp<T>(*this);
}

template <class T> //VIEJO
void ListaPosImp<T>::Imprimir(ostream& o) const {
	for (Iterador<T> &i = GetIterador(); !i.EsFin();) {
		Iterador<T> aux = i;
		aux.Resto();
		if (aux.EsFin())
			o << i++;
		else
			o << i++ << " ";
	}
}

template <class T> //CLASE
void ListaPosImp<T>::expandir() {
	if (this->cantidadElementos == this->largoVector){
		T* nuevo = new T[this->largoVector * 2];
		for (int i = 0; i < this->cantidadElementos; i++){
			nuevo[i] = this->vector[i];
		}
		this->largoVector = this->largoVector * 2;
		delete[] this->vector;
		this->vector = nuevo;
	}
}

template <class T> //CLASE
void ListaPosImp<T>::correrHaciaAdelante(int desde) {
	for (int i = this->cantidadElementos - 1; i >= desde; i--) {
		this->vector[i + 1] = this->vector[i];
	}
}

template <class T> //CLASE
void ListaPosImp<T>::correrHaciaAtras(int hasta) { //hasta tiene que ser mayor o igual a 0
	for (int i = hasta; i < this->cantidadElementos; i++) {
		this->vector[i] = this->vector[i + 1];
	}
}

#endif