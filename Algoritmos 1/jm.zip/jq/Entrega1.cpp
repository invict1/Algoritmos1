#include "Entrega1.h"

#ifndef ENTREGA1_CPP
#define ENTREGA1_CPP

void EnlistarAux(NodoAB* a, ListaOrd<int>* &lista) //CLASE
{	//podr�a ir sin el & poque pasamos la direcci�n de memoria y no la lista entera
	if (a != NULL) {
		lista->AgregarOrd(a->dato);
		EnlistarAux(a->izq, lista);
		EnlistarAux(a->der, lista);
	}
}

ListaOrd<int>* Enlistar(NodoAB* a) //CLASE
{
	ListaOrd<int>* lista = new ListaOrdImp<int>();
	EnlistarAux(a, lista);
	return lista;
}

int CantidadDeHojas(NodoAB* a) //CLASE
{
	if (a == NULL) return 0;
	Pila<NodoAB*> *pila = new PilaImp<NodoAB*>();
	pila->Push(a);
	int cantidad = 0;
	while (!pila->EsVacia()){
		NodoAB* nodo = pila->Pop();
		if (nodo->der == NULL && nodo->izq == NULL)
			cantidad++;
		if (nodo->der != NULL)
			pila->Push(nodo->der);
		if (nodo->izq != NULL)
			pila->Push(nodo->izq);
	}
	delete pila;
	return cantidad;
}

void ImprimirPorNiveles(NodoAB *a) //VIEJO
{ 
	Cola<NodoAB*>* c = new ColaImp<NodoAB*>();
	Pila<int>* p = new PilaImp<int>();
	if (a != NULL) c->Encolar(a);
	while (!c->EsVacia()) {
		NodoAB* arbActual = c->Principio();
		p->Push(arbActual->dato);
		if (arbActual->izq != NULL) c->Encolar(arbActual->izq);
		if (arbActual->der != NULL) c->Encolar(arbActual->der);
		c->Desencolar();
	}
	while (!p->EsVacia()) {
		cout << p->Pop() << " ";
	}
	delete p;
	delete c;
}

#endif