#pragma once

#include "FuncAux.h"
#include "Defensa.h"
#include "FuncAuxTAD.h"
