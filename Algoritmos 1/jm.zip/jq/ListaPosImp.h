#ifndef LISTAPOSIMP_H			// PRONTO
#define LISTAPOSIMP_H

#include <assert.h>
#include "ListaPos.h"
#include "IteradorListaPosImp.h"
#include "NodoLista.h"

template <class T>
class IteradorListaPosImp;

template <class T>
class ListaPosImp : public ListaPos<T> {
	friend class IteradorListaPosImp<T>;
	friend ostream &operator<<(ostream& o, const ListaPosImp<T> & l);
public:
	// Constructor por defecto
	ListaPosImp();	//tiene que estar si o si

	// Constructor copia
	ListaPosImp(const ListaPos<T> &l);	//recibe cualquier tipo de objeto que herede de ListaPos, es gen�rico, recibe cualquier tipo de lista
	ListaPosImp(const ListaPosImp<T> &l);	////tiene que estar si o si, recibe una lista del la clase

	// Operador de asignacion
	ListaPos<T> &operator=(const ListaPos<T> &l);
	ListaPos<T> &operator=(const ListaPosImp<T> &l); //tiene que estar si o si

	// Para ver la documentacion del resto de las funciones ver la especificacion
	ListaPos<T> *CrearVacia() const; //retornar una instancia nueva de esta clase
	virtual ~ListaPosImp();	//tiene que estar si o si

	void AgregarPpio(const T &e);
	void AgregarFin(const T &e);
	void AgregarPos(const T &e, unsigned int pos);
	
	void BorrarPpio();	
	void BorrarFin();
	void BorrarPos(unsigned int pos);
	void Borrar(const T &e);

	T& ElementoPpio() const;
	T& ElementoFin() const;
	T& ElementoPos(unsigned int pos) const;
	
	unsigned int Posicion(const T &e) const;
	bool Existe(const T &e) const;	

	void Vaciar();

	unsigned int CantidadElementos() const;

	bool EsVacia() const;
	bool EsLlena() const;
	
	ListaPos<T>* Clon() const;

	Iterador<T> GetIterador() const;
	void Imprimir(ostream& o) const;

protected:
	// Atributos de la clase -- poner los atributos de la clase y las funciones auxiliares
	T* vector; //para que el tipo lo elija la persona que lo vaya a implementar
	int largoVector; 
	int cantidadElementos; // para conocer hasta donde voy porque cuando lo inicializamos, hay basura en el resto de las posiciones

	void expandir(); //que chequee si se tiene que expandir y despues expandir o no
	void correrHaciaAdelante(int desde); //para correr desde ese desde hasta la cantidad de elementos
	void correrHaciaAtras(int hasta); //
};

#include "ListaPosImp.cpp"

#endif